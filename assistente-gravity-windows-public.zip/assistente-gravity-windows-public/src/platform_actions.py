"""Desktop actions shared by the local browser interface on macOS and Windows."""
import os
import subprocess
import sys
from pathlib import Path


def open_path(path, app=None, reveal=False, clipboard=False):
    target = Path(path).resolve(strict=True)
    if sys.platform == 'win32':
        if clipboard:
            env = dict(os.environ, GRAVITY_FILE=str(target))
            subprocess.run(['powershell.exe', '-NoProfile', '-NonInteractive', '-Command',
                            'Set-Clipboard -LiteralPath $env:GRAVITY_FILE'], env=env, check=True)
        elif reveal:
            subprocess.Popen(['explorer.exe', '/select,', str(target)])
        else:
            os.startfile(str(target))
    elif sys.platform == 'darwin':
        if clipboard:
            subprocess.run(['osascript', '-e', 'on run argv\nset the clipboard to (POSIX file (item 1 of argv))\nend run', str(target)], check=True)
        else:
            subprocess.Popen(['open'] + (['-R'] if reveal else ['-a', app] if app else []) + [str(target)])
    else:
        subprocess.Popen(['xdg-open', str(target.parent if reveal else target)])
