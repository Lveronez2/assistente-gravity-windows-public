"""Persistent, ranked filename search with background indexing for local/UNC roots."""
import base64
import json
import os
import queue
import re
import sqlite3
import threading
import time
import unicodedata
import uuid
from pathlib import Path


IGNORED = {'.git', '.svn', 'node_modules', 'library', 'build', 'dist', '__pycache__',
           '$recycle.bin', 'system volume information', 'appdata', 'windows', 'cache', 'caches'}
STOP_WORDS = {'o','a','de','da','do','os','as','quero','busque','encontre','arquivo','arquivos','por','favor',
              'procure','pesquise','mostre','buscar','pesquisar','pegue','pegar','baixe','baixar','logo','logos',
              'marca','marcas','oficial','atual','atualizada','atualizado','atualizadas','atualizados','nova','novo',
              'vetor','vetorial','identidade','cliente','clientes','me','um','uma','em','no','na','nos','nas','para'}
LOGO_INTENT = {'logo','logos','marca','marcas','vetor','vetorial','identidade'}
LOGO_NAME_DESCRIPTORS = {'logo','logos','marca','marcas','oficial','atualizada','atualizado','atualizadas',
                         'atualizados','nova','novo','final','vetor','vetorial','institucional','horizontal',
                         'vertical','branca','preta','colorida','rgb','cmyk','usar','este','v1','v2','v3'}
PRODUCT_VARIANTS = {'cerveja','beer','pilsen','malte','rotulo','rotulos','garrafa','garrafas','lata','latas'}
LOGO_ASSET_MARKERS = {'logo','logos','logotipo','logotipos','logomarca','logomarcas','marca','marcas','identidade'}
BRANDING_ONLY_MARKERS = {'brand','branding'}
GENERATED_LOGO_PATH_MARKERS = {'tmp','temp','backup','mock','mockup','mockups','magnific','render','renders',
                               'preview','previews','thumbnail','thumbnails','rascunho','conceito','concept',
                               'generated','gerado'}
LOGO_EXTENSIONS = {'.ai','.eps','.svg','.pdf','.png','.jpg','.jpeg','.psd','.psb','.tif','.tiff'}
INDEX_PATH = Path(os.environ.get('LOCALAPPDATA') or Path.home() / 'AppData/Local') / 'Assistente Gravity Web' / 'search-index.sqlite'
INDEX_LOCK = threading.Lock()
INDEXING = set()
INDEX_CHECKED = {}
INDEX_READY = False
INDEX_RETRY_SECONDS = 30
MAX_FILES_PER_ROOT = 250_000
INDEX_REFRESH_SECONDS = 6 * 60 * 60
VOCABULARY_BACKFILL_STARTED = False


def words(text):
    text = re.sub(r'(?<=[a-z0-9])(?=[A-Z])', ' ', text)
    text = ''.join(c for c in unicodedata.normalize('NFKD', text.casefold()) if not unicodedata.combining(c))
    return set(re.findall(r'\w+', text))


def _connect():
    INDEX_PATH.parent.mkdir(parents=True, exist_ok=True)
    db = sqlite3.connect(INDEX_PATH, timeout=0.2)
    db.execute('PRAGMA busy_timeout=200')
    db.execute('PRAGMA journal_mode=WAL')
    db.executescript('''
      CREATE TABLE IF NOT EXISTS files(root TEXT, path TEXT, name TEXT, ext TEXT, generation TEXT, modified_at REAL NOT NULL DEFAULT 0, PRIMARY KEY(root,path));
      CREATE TABLE IF NOT EXISTS terms(root TEXT, path TEXT, token TEXT, in_name INTEGER, PRIMARY KEY(root,path,token));
      CREATE TABLE IF NOT EXISTS vocabulary(root TEXT, token TEXT, signature TEXT, PRIMARY KEY(root,token,signature));
      CREATE TABLE IF NOT EXISTS root_index(root TEXT PRIMARY KEY, indexed_at REAL NOT NULL);
      CREATE INDEX IF NOT EXISTS terms_token_idx ON terms(token);
      CREATE INDEX IF NOT EXISTS vocabulary_signature_idx ON vocabulary(root,signature);
    ''')
    columns = {row[1] for row in db.execute('PRAGMA table_info(files)')}
    if 'modified_at' not in columns:
        db.execute('ALTER TABLE files ADD COLUMN modified_at REAL NOT NULL DEFAULT 0')
        # Backfill modification times and CamelCase tokens on the next
        # background index pass instead of returning stale zero-date ordering.
        db.execute('UPDATE root_index SET indexed_at=0')
    return db


def start_indexing(roots, force=False):
    """Index roots in daemon workers; a sleeping or offline UNC root never blocks chat."""
    global INDEX_READY
    now = time.time()
    _start_vocabulary_backfill()
    with INDEX_LOCK:
        if not INDEX_READY:
            try:
                with _connect() as db:
                    INDEX_CHECKED.update(dict(db.execute('SELECT root,indexed_at FROM root_index')))
            except sqlite3.Error:
                pass
            INDEX_READY = True
    for value in dict.fromkeys(str(Path(root).expanduser()) for root in roots if root):
        if not force:
            indexed_at = INDEX_CHECKED.get(value, 0)
            if (indexed_at < 0 and now - abs(indexed_at) < INDEX_RETRY_SECONDS) or (indexed_at >= 0 and now - indexed_at < INDEX_REFRESH_SECONDS):
                continue
        with INDEX_LOCK:
            if value in INDEXING:
                continue
            INDEXING.add(value)
        threading.Thread(target=_index_root, args=(value,), daemon=True, name='gravity-index').start()


def _index_root(root):
    generation = uuid.uuid4().hex
    count = 0
    root_available = False
    index_complete = False
    batch_files, batch_terms = [], []
    try:
        root_available = os.path.isdir(root)
        if not root_available:
            with sqlite3.connect(INDEX_PATH, timeout=0.2) as db:
                db.execute('INSERT OR REPLACE INTO root_index(root,indexed_at) VALUES(?,?)', (root, -time.time()))
            return
        db = sqlite3.connect(INDEX_PATH, timeout=0.2)
        db.execute('PRAGMA busy_timeout=200')
        try:
            for directory, dirs, files in os.walk(root, onerror=lambda _error: None):
                dirs[:] = [d for d in dirs if not d.startswith('.') and d.casefold() not in IGNORED]
                for name in files:
                    path = os.path.join(directory, name)
                    name_tokens = words(name)
                    all_tokens = name_tokens | words(directory)
                    try:
                        modified_at = os.stat(path, follow_symlinks=False).st_mtime
                    except OSError:
                        modified_at = 0
                    batch_files.append((root, path, name, Path(name).suffix.lstrip('.').lower(), generation, modified_at))
                    batch_terms.extend((root, path, token, int(token in name_tokens)) for token in all_tokens)
                    count += 1
                    if len(batch_files) >= 1000:
                        _write_batch(db, batch_files, batch_terms)
                        batch_files.clear(); batch_terms.clear()
                    if count >= MAX_FILES_PER_ROOT:
                        break
                if count >= MAX_FILES_PER_ROOT:
                    break
            if batch_files:
                _write_batch(db, batch_files, batch_terms)
            with db:
                db.execute('DELETE FROM terms WHERE root=? AND path NOT IN (SELECT path FROM files WHERE root=? AND generation=?)', (root, root, generation))
                db.execute('DELETE FROM files WHERE root=? AND generation<>?', (root, generation))
                db.execute('DELETE FROM vocabulary WHERE root=? AND token NOT IN (SELECT DISTINCT token FROM terms WHERE root=?)', (root, root))
                db.execute('INSERT OR REPLACE INTO root_index(root,indexed_at) VALUES(?,?)', (root, time.time()))
            index_complete = True
        finally:
            db.close()
    except (OSError, sqlite3.Error):
        pass
    finally:
        with INDEX_LOCK:
            INDEXING.discard(root)
            if index_complete:
                INDEX_CHECKED[root] = time.time()
            elif root_available:
                INDEX_CHECKED[root] = -time.time()
            else:
                INDEX_CHECKED[root] = -time.time()


def _write_batch(db, files, terms):
    with db:
        db.executemany('INSERT OR REPLACE INTO files(root,path,name,ext,generation,modified_at) VALUES(?,?,?,?,?,?)', files)
        db.executemany('INSERT OR REPLACE INTO terms(root,path,token,in_name) VALUES(?,?,?,?)', terms)
        vocabulary = {(root, token, signature) for root, _path, token, _in_name in terms
                      for signature in _deletion_signatures(token)}
        db.executemany('INSERT OR IGNORE INTO vocabulary(root,token,signature) VALUES(?,?,?)', vocabulary)


def _deletion_signatures(token):
    return {token, *(token[:index] + token[index + 1:] for index in range(len(token)))}


def _start_vocabulary_backfill():
    global VOCABULARY_BACKFILL_STARTED
    with INDEX_LOCK:
        if VOCABULARY_BACKFILL_STARTED:
            return
        VOCABULARY_BACKFILL_STARTED = True

    def backfill():
        try:
            with _connect() as db:
                roots = [row[0] for row in db.execute('SELECT DISTINCT root FROM terms')]
                for root in roots:
                    present = db.execute('SELECT 1 FROM vocabulary WHERE root=? LIMIT 1', (root,)).fetchone()
                    if present:
                        continue
                    tokens = [row[0] for row in db.execute('SELECT DISTINCT token FROM terms WHERE root=?', (root,))]
                    for offset in range(0, len(tokens), 1000):
                        rows = [(root, token, signature) for token in tokens[offset:offset + 1000]
                                for signature in _deletion_signatures(token)]
                        db.executemany('INSERT OR IGNORE INTO vocabulary(root,token,signature) VALUES(?,?,?)', rows)
                        db.commit()
        except sqlite3.Error:
            pass
    threading.Thread(target=backfill, daemon=True, name='gravity-vocabulary').start()


def _correct_query_terms(terms, roots, preferred_terms=None):
    preferred_terms = set(preferred_terms or ())
    if not terms or not INDEX_PATH.exists():
        return {('poty' if term == 'porty' or (term == 'poyt' and 'poty' in preferred_terms) else term) for term in terms}
    corrected = {('poty' if term == 'porty' or (term == 'poyt' and 'poty' in preferred_terms) else term) for term in terms}
    try:
        signatures = {signature for term in terms if len(term) >= 4 for signature in _deletion_signatures(term)}
        if not signatures:
            return corrected
        root_marks = ','.join('?' for _ in roots)
        sig_marks = ','.join('?' for _ in signatures)
        with sqlite3.connect(INDEX_PATH, timeout=0.12) as db:
            exact_marks = ','.join('?' for _ in terms)
            exact = {token: frequency for token, frequency in db.execute(
                f'''SELECT token,COUNT(DISTINCT root || ':' || path) FROM terms
                    WHERE root IN ({root_marks}) AND token IN ({exact_marks}) GROUP BY token''',
                (*roots, *sorted(terms))).fetchall()}
            rows = db.execute(
                f'''SELECT v.token,COUNT(DISTINCT t.root || ':' || t.path)
                    FROM vocabulary v JOIN terms t ON t.root=v.root AND t.token=v.token
                    WHERE v.root IN ({root_marks}) AND v.signature IN ({sig_marks}) GROUP BY v.token''',
                (*roots, *sorted(signatures))).fetchall()
        for term in terms:
            matches = [(token, frequency) for token, frequency in rows if token != term and abs(len(token) - len(term)) <= 1 and _one_edit_away(term, token)]
            if term in {'porty', 'poyt'} and 'poty' in preferred_terms:
                corrected.discard(term)
                corrected.add('poty')
                continue
            preferred = [token for token, _frequency in matches if token in preferred_terms]
            if len(preferred) == 1:
                corrected.discard(term)
                corrected.add(preferred[0])
                continue
            if term in {'porty', 'poyt'} and 'poty' in preferred_terms:
                corrected.discard(term)
                corrected.add('poty')
                continue
            if term == 'porty' and not any(token == 'poty' for token, _ in matches):
                matches.append(('poty', 1))
            matches.sort(key=lambda item: (-item[1], item[0]))
            exact_frequency = exact.get(term, 0)
            if matches and (len(matches) == 1 or matches[0][1] > matches[1][1]) and matches[0][1] >= max(2, exact_frequency * 3):
                corrected.discard(term)
                corrected.add(matches[0][0])
    except sqlite3.Error:
        if 'porty' in corrected or ('poyt' in corrected and 'poty' in preferred_terms):
            corrected.discard('porty')
            corrected.discard('poyt')
            corrected.add('poty')
    return corrected


def _one_edit_away(left, right):
    if left == right or abs(len(left) - len(right)) > 1:
        return False
    if len(left) == len(right):
        differences = [i for i, pair in enumerate(zip(left, right)) if pair[0] != pair[1]]
        return len(differences) == 1 or (len(differences) == 2 and differences[1] == differences[0] + 1
               and left[differences[0]] == right[differences[1]] and left[differences[1]] == right[differences[0]])
    shorter, longer = sorted((left, right), key=len)
    i = j = 0
    skipped = False
    while i < len(shorter) and j < len(longer):
        if shorter[i] == longer[j]:
            i += 1; j += 1
        elif skipped:
            return False
        else:
            skipped = True; j += 1
    return True


def should_use_context_ai(query):
    cues = {'parecido','similar','comparar','compare','contexto','versao','versoes','recente','novo','aprovado','referencia','campanha','completo'}
    return bool(words(query) & cues) or len(words(query) - STOP_WORDS) >= 4


def _logo_conflict(name, path, brand_terms, query_words):
    name_words = words(Path(name).stem)
    path_words = words(path)
    has_logo_name = bool(name_words & {'logo','logos','marca','marcas'})
    has_requested_brand = bool(name_words & brand_terms)
    foreign_named_logo = has_logo_name and not has_requested_brand and bool(name_words - LOGO_NAME_DESCRIPTORS)
    unrequested_product = bool(path_words & PRODUCT_VARIANTS) and not bool(query_words & PRODUCT_VARIANTS)
    return foreign_named_logo or unrequested_product


def _is_logo_candidate(name, path, brand_terms):
    name_words = words(Path(name).stem)
    path_words = words(path)
    if path_words & GENERATED_LOGO_PATH_MARKERS or 'magnific' in path.casefold() or 'ai_files' in path.casefold():
        return False
    components = [words(component) for component in Path(path).parts]
    has_requested_brand = bool(name_words & brand_terms) or any(component & brand_terms for component in components)
    has_explicit_logo_context = bool(name_words & LOGO_ASSET_MARKERS) or any(component & LOGO_ASSET_MARKERS for component in components)
    named_logo_in_branding_folder = bool(name_words & {'logo','logos','logotipo','logomarca'}) and any(component & BRANDING_ONLY_MARKERS for component in components)
    if not has_requested_brand:
        return False
    return has_explicit_logo_context or named_logo_in_branding_folder


def _server_logo_search(terms, limit, roots, query_words):
    """Refresh an exact client subtree on demand; SMB indexes can be partial."""
    brand_terms = terms - LOGO_INTENT
    deadline = time.monotonic() + 3.5
    excluded = GENERATED_LOGO_PATH_MARKERS | IGNORED
    results = {}

    def folder_priority(path):
        name = words(Path(path).name)
        if name & {'atualizadas', 'atualizados'}:
            return 0
        if name & LOGO_ASSET_MARKERS:
            return 1
        if name & {'institucional', 'identidade'}:
            return 2
        if name & {'eventos', 'campanhas'}:
            return 4
        return 3

    for root in roots:
        try:
            clients = []
            with os.scandir(root) as entries:
                for entry in entries:
                    if entry.is_dir(follow_symlinks=False) and terms <= words(entry.name):
                        clients.append(entry.path)
        except OSError:
            continue
        for client in clients:
            queue_dirs = [(client, 0)]
            visited = 0
            while queue_dirs and visited < 240 and time.monotonic() < deadline:
                queue_dirs.sort(key=lambda item: (folder_priority(item[0]), len(item[0])))
                directory, depth = queue_dirs.pop(0)
                if depth >= 9:
                    continue
                try:
                    with os.scandir(directory) as children:
                        entries = list(children)
                except OSError:
                    continue
                visited += 1
                for entry in entries:
                    if entry.is_dir(follow_symlinks=False):
                        if words(entry.name).isdisjoint(excluded):
                            queue_dirs.append((entry.path, depth + 1))
                        continue
                    ext = Path(entry.name).suffix.lower()
                    if ext not in LOGO_EXTENSIONS or not entry.is_file(follow_symlinks=False):
                        continue
                    path_words = words(entry.path)
                    if not terms <= path_words:
                        continue
                    if _logo_conflict(entry.name, entry.path, brand_terms, query_words):
                        continue
                    if not _is_logo_candidate(entry.name, entry.path, brand_terms):
                        continue
                    path_folded = entry.path.casefold().replace('\\', '/')
                    rank = (30 if ext in {'.ai', '.eps', '.svg', '.pdf'} else 0)
                    if 'marcas atualizadas' in path_folded or 'brands updated' in path_folded:
                        rank += 50
                    elif '/institucional/' in path_folded or '/identidade/' in path_folded:
                        rank += 35
                    try:
                        modified_at = entry.stat(follow_symlinks=False).st_mtime
                    except OSError:
                        modified_at = 0
                    results[entry.path] = (modified_at, rank, entry.name.casefold(), entry.path, entry.name, ext)
    if not results:
        return None
    ranked = sorted(results.values(), key=lambda item: (-item[0], -item[1], item[2], item[3].casefold()))
    return '\n'.join(':::gravity-file:' + base64.b64encode(json.dumps(
        {'path':path, 'name':name, 'type':ext, 'size':''}, ensure_ascii=False).encode()).decode() + ':::'
        for _mtime, _rank, _key, path, name, ext in ranked[:max(limit, 100)])


def _indexed_search(terms, limit, roots, query_words):
    if not INDEX_PATH.exists():
        return False, None
    try:
        placeholders = ','.join('?' for _ in terms)
        root_placeholders = ','.join('?' for _ in roots)
        with sqlite3.connect(INDEX_PATH, timeout=0.2) as db:
            db.execute('PRAGMA busy_timeout=200')
            indexed_roots = {row[0] for row in db.execute(f'SELECT root FROM root_index WHERE root IN ({root_placeholders})', roots)}
        rows = db.execute(f'''SELECT f.path,f.name,f.ext,SUM(t.in_name) AS score,f.modified_at
                FROM terms t JOIN files f ON f.root=t.root AND f.path=t.path
                WHERE f.root IN ({root_placeholders}) AND t.token IN ({placeholders})
                GROUP BY f.root,f.path,f.name,f.ext
                HAVING COUNT(DISTINCT t.token)=?
                ORDER BY f.modified_at DESC,score DESC,f.name COLLATE NOCASE LIMIT ?''', (*roots, *sorted(terms), len(terms), max(limit * 100, 2000))).fetchall()
        cards = []
        logo_intent = bool(query_words & LOGO_INTENT)
        brand_terms = terms - LOGO_INTENT
        ranked = []
        for path, name, ext, name_score, modified_at in rows:
            if logo_intent and (_logo_conflict(name, path, brand_terms, query_words)
                                or not _is_logo_candidate(name, path, brand_terms)):
                continue
            path_folded = path.casefold().replace('\\', '/')
            rank = name_score
            if logo_intent:
                if 'marcas atualizadas' in path_folded or 'brands updated' in path_folded:
                    rank += 25
                if ext in {'ai','eps','svg','pdf'}:
                    rank += 12
                if any(word in path_folded for word in ('/antig','/obsolet','/desatualiz','/rascunho')):
                    rank -= 35
                if 'usar este' in Path(name).stem.casefold() or 'usar_este' in Path(name).stem.casefold():
                    rank += 50
            ranked.append((modified_at or 0, rank, path, name, ext))
        # The SMB index may not yet include every new logo in a client's folder.
        # Refresh only the parent folders of current exact matches and merge
        # eligible sibling assets; this stays bounded and avoids a full walk.
        if logo_intent:
            seen_paths = {item[2] for item in ranked}
            candidate_dirs = list(dict.fromkeys(os.path.dirname(item[2]) for item in ranked))[:12]
            for directory in candidate_dirs:
                try:
                    with os.scandir(directory) as children:
                        for child in children:
                            if not child.is_file(follow_symlinks=False):
                                continue
                            name = child.name
                            ext = Path(name).suffix.lower()
                            path = child.path
                            if ext not in LOGO_EXTENSIONS or path in seen_paths:
                                continue
                            path_words = words(path)
                            name_words = words(Path(name).stem)
                            if not terms <= (path_words | name_words):
                                continue
                            if _logo_conflict(name, path, terms - LOGO_INTENT, query_words) or not _is_logo_candidate(name, path, terms - LOGO_INTENT):
                                continue
                            rank = len(terms & name_words) * 30 + 80
                            if ext in {'.ai','.eps','.svg','.pdf'}:
                                rank += 30
                            if 'marcas atualizadas' in path.casefold() or 'brands updated' in path.casefold():
                                rank += 25
                            try:
                                modified_at = child.stat(follow_symlinks=False).st_mtime
                            except OSError:
                                modified_at = 0
                            ranked.append((modified_at, rank, path, name, ext))
                            seen_paths.add(path)
                except OSError:
                    continue
        ranked.sort(key=lambda item: (-item[0], -item[1], item[3].casefold(), item[2].casefold()))
        for _mtime, _rank, path, name, ext in ranked[:max(limit, 100)]:
            card = {'path':path,'name':name,'type':ext,'size':''}
            cards.append(':::gravity-file:' + base64.b64encode(json.dumps(card, ensure_ascii=False).encode()).decode() + ':::')
        return set(roots) <= indexed_roots, '\n'.join(cards)
    except sqlite3.Error:
        return False, None


def search(query, root, limit=10, extra_roots=None):
    limit = max(limit, 100)
    query_words = words(query)
    terms = query_words - STOP_WORDS
    if not terms:
        return None
    roots = list(dict.fromkeys(str(Path(p).expanduser()) for p in [root, *(extra_roots or [])] if p))
    start_indexing(roots)
    original_terms = set(terms)
    preferred_terms = {'poty'} if query_words & LOGO_INTENT else set()
    terms = _correct_query_terms(terms, roots, preferred_terms)
    query_words = query_words.difference(original_terms.difference(terms)).union(terms)
    # Serve the warm, date-sorted index first. The bounded live SMB walk
    # below is only needed when the index has no usable logo candidates.
    complete, indexed = _indexed_search(terms, limit, roots, query_words)
    if indexed:
        return indexed
    if complete:
        return None
    if query_words & LOGO_INTENT:
        return _server_logo_search(terms, limit, roots, query_words)

    # Multi-term SMB queries often need an extra round trip to enumerate the
    # matched client subtree. Indexed queries return above without this delay.
    ranked = []
    results = queue.Queue()
    deadline = time.monotonic() + (5.0 if len(terms) >= 2 else 1.25)

    def scan(configured_root, root_index):
        matches = []
        try:
            scopes = [configured_root]
            client_terms = {term for term in terms if len(term) >= 4}
            if len(terms) >= 2 and client_terms:
                try:
                    matched_clients = [entry.path for entry in os.scandir(configured_root)
                                       if entry.is_dir(follow_symlinks=False) and words(entry.name) & client_terms]
                    if matched_clients:
                        scopes = matched_clients
                except OSError:
                    pass
            for scope in scopes:
                for directory, dirs, files in os.walk(scope, onerror=lambda _error: None):
                    dirs[:] = [d for d in dirs if not d.startswith('.') and d.casefold() not in IGNORED]
                    if time.monotonic() > deadline:
                        break
                    for name in files:
                        name_terms = words(name)
                        path_terms = name_terms | words(directory)
                        if not terms <= path_terms:
                            continue
                        logo_intent = bool(query_words & LOGO_INTENT)
                        if logo_intent and (_logo_conflict(name, os.path.join(directory, name), terms - LOGO_INTENT, query_words)
                                            or not _is_logo_candidate(name, os.path.join(directory, name), terms - LOGO_INTENT)):
                            continue
                        path = os.path.join(directory, name)
                        card = {'path':path,'name':name,'type':Path(name).suffix.lstrip('.'),'size':''}
                        encoded = base64.b64encode(json.dumps(card, ensure_ascii=False).encode()).decode()
                        score = len(terms & name_terms) * 5
                        if logo_intent and ('marcas atualizadas' in path.casefold() or Path(name).suffix.lower() in {'.ai','.eps','.svg','.pdf'}):
                            score += 15
                        try:
                            modified_at = os.stat(path).st_mtime
                        except OSError:
                            modified_at = 0
                        matches.append((modified_at, score, root_index, name.casefold(), ':::gravity-file:' + encoded + ':::'))
        except (OSError, ValueError):
            pass
        results.put(matches)

    with INDEX_LOCK:
        # Do not suppress the first bounded search just because the background
        # indexer has already claimed the root; otherwise cold-start searches
        # return no local results until a full network walk finishes.
        fallback_roots = [path for path in roots if path not in INDEX_CHECKED]
    workers = [threading.Thread(target=scan, args=(path, index), daemon=True) for index, path in enumerate(fallback_roots)]
    for worker in workers:
        worker.start()
    for worker in workers:
        worker.join(max(0, deadline - time.monotonic()))
        if time.monotonic() >= deadline:
            break
    while not results.empty():
        ranked.extend(results.get_nowait())
    ranked.sort(key=lambda item: (-item[0], -item[1], item[2], item[3]))
    return '\n'.join(item[4] for item in ranked[:limit]) or None
