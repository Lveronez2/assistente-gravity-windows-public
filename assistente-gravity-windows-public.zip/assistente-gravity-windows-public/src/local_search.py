"""Persistent, ranked filename search with background indexing for local/UNC roots."""
import base64
import json
import os
import queue
import re
import sqlite3
import threading
import time
import unicodedata
import uuid
from pathlib import Path


IGNORED = {'.git', '.svn', 'node_modules', 'library', 'build', 'dist', '__pycache__',
           '$recycle.bin', 'system volume information', 'appdata', 'windows', 'cache', 'caches'}
STOP_WORDS = {'o','a','de','da','do','os','as','quero','busque','encontre','arquivo','arquivos','por','favor',
              'procure','pesquise','mostre','buscar','pesquisar','pegue','pegar','baixe','baixar','logo','logos',
              'marca','marcas','oficial','atual','atualizada','atualizado','atualizadas','atualizados','nova','novo',
              'vetor','vetorial','identidade','cliente','clientes','me','um','uma','em','no','na','nos','nas','para'}
LOGO_INTENT = {'logo','logos','marca','marcas','vetor','vetorial','identidade'}
LOGO_NAME_DESCRIPTORS = {'logo','logos','marca','marcas','oficial','atualizada','atualizado','atualizadas',
                         'atualizados','nova','novo','final','vetor','vetorial','institucional','horizontal',
                         'vertical','branca','preta','colorida','rgb','cmyk','usar','este','v1','v2','v3'}
PRODUCT_VARIANTS = {'cerveja','beer','pilsen','malte','rotulo','rotulos','garrafa','garrafas','lata','latas'}
INDEX_PATH = Path(os.environ.get('LOCALAPPDATA') or Path.home() / 'AppData/Local') / 'Assistente Gravity Web' / 'search-index.sqlite'
INDEX_LOCK = threading.Lock()
INDEXING = set()
INDEX_CHECKED = {}
INDEX_READY = False
INDEX_RETRY_SECONDS = 30
MAX_FILES_PER_ROOT = 250_000
INDEX_REFRESH_SECONDS = 6 * 60 * 60


def words(text):
    text = ''.join(c for c in unicodedata.normalize('NFKD', text.casefold()) if not unicodedata.combining(c))
    return set(re.findall(r'\w+', text))


def _connect():
    INDEX_PATH.parent.mkdir(parents=True, exist_ok=True)
    db = sqlite3.connect(INDEX_PATH, timeout=0.2)
    db.execute('PRAGMA busy_timeout=200')
    db.execute('PRAGMA journal_mode=WAL')
    db.executescript('''
      CREATE TABLE IF NOT EXISTS files(root TEXT, path TEXT, name TEXT, ext TEXT, generation TEXT, PRIMARY KEY(root,path));
      CREATE TABLE IF NOT EXISTS terms(root TEXT, path TEXT, token TEXT, in_name INTEGER, PRIMARY KEY(root,path,token));
      CREATE TABLE IF NOT EXISTS root_index(root TEXT PRIMARY KEY, indexed_at REAL NOT NULL);
      CREATE INDEX IF NOT EXISTS terms_token_idx ON terms(token);
    ''')
    return db


def start_indexing(roots, force=False):
    """Index roots in daemon workers; a sleeping or offline UNC root never blocks chat."""
    global INDEX_READY
    now = time.time()
    with INDEX_LOCK:
        if not INDEX_READY:
            try:
                with _connect() as db:
                    INDEX_CHECKED.update(dict(db.execute('SELECT root,indexed_at FROM root_index')))
            except sqlite3.Error:
                pass
            INDEX_READY = True
    for value in dict.fromkeys(str(Path(root).expanduser()) for root in roots if root):
        if not force:
            indexed_at = INDEX_CHECKED.get(value, 0)
            if (indexed_at < 0 and now - abs(indexed_at) < INDEX_RETRY_SECONDS) or (indexed_at >= 0 and now - indexed_at < INDEX_REFRESH_SECONDS):
                continue
        with INDEX_LOCK:
            if value in INDEXING:
                continue
            INDEXING.add(value)
        threading.Thread(target=_index_root, args=(value,), daemon=True, name='gravity-index').start()


def _index_root(root):
    generation = uuid.uuid4().hex
    count = 0
    root_available = False
    index_complete = False
    batch_files, batch_terms = [], []
    try:
        root_available = os.path.isdir(root)
        if not root_available:
            with sqlite3.connect(INDEX_PATH, timeout=0.2) as db:
                db.execute('INSERT OR REPLACE INTO root_index(root,indexed_at) VALUES(?,?)', (root, -time.time()))
            return
        db = sqlite3.connect(INDEX_PATH, timeout=0.2)
        db.execute('PRAGMA busy_timeout=200')
        try:
            for directory, dirs, files in os.walk(root, onerror=lambda _error: None):
                dirs[:] = [d for d in dirs if not d.startswith('.') and d.casefold() not in IGNORED]
                for name in files:
                    path = os.path.join(directory, name)
                    name_tokens = words(name)
                    all_tokens = name_tokens | words(directory)
                    batch_files.append((root, path, name, Path(name).suffix.lstrip('.').lower(), generation))
                    batch_terms.extend((root, path, token, int(token in name_tokens)) for token in all_tokens)
                    count += 1
                    if len(batch_files) >= 1000:
                        _write_batch(db, batch_files, batch_terms)
                        batch_files.clear(); batch_terms.clear()
                    if count >= MAX_FILES_PER_ROOT:
                        break
                if count >= MAX_FILES_PER_ROOT:
                    break
            if batch_files:
                _write_batch(db, batch_files, batch_terms)
            with db:
                db.execute('DELETE FROM terms WHERE root=? AND path NOT IN (SELECT path FROM files WHERE root=? AND generation=?)', (root, root, generation))
                db.execute('DELETE FROM files WHERE root=? AND generation<>?', (root, generation))
                db.execute('INSERT OR REPLACE INTO root_index(root,indexed_at) VALUES(?,?)', (root, time.time()))
            index_complete = True
        finally:
            db.close()
    except (OSError, sqlite3.Error):
        pass
    finally:
        with INDEX_LOCK:
            INDEXING.discard(root)
            if index_complete:
                INDEX_CHECKED[root] = time.time()
            elif root_available:
                INDEX_CHECKED[root] = -time.time()
            else:
                INDEX_CHECKED[root] = -time.time()


def _write_batch(db, files, terms):
    with db:
        db.executemany('INSERT OR REPLACE INTO files(root,path,name,ext,generation) VALUES(?,?,?,?,?)', files)
        db.executemany('INSERT OR REPLACE INTO terms(root,path,token,in_name) VALUES(?,?,?,?)', terms)


def _logo_conflict(name, path, brand_terms, query_words):
    name_words = words(Path(name).stem)
    path_words = words(path)
    has_logo_name = bool(name_words & {'logo','logos','marca','marcas'})
    has_requested_brand = bool(name_words & brand_terms)
    foreign_named_logo = has_logo_name and not has_requested_brand and bool(name_words - LOGO_NAME_DESCRIPTORS)
    unrequested_product = bool(path_words & PRODUCT_VARIANTS) and not bool(query_words & PRODUCT_VARIANTS)
    return foreign_named_logo or unrequested_product


def _is_logo_candidate(name, path, brand_terms):
    if words(Path(name).stem) & brand_terms:
        return True
    components = [words(component) for component in Path(path).parts]
    has_brand_folder = any(component & brand_terms for component in components)
    branding_context = {'logo','logos','marca','marcas','identidade','brand','branding','atualizadas','atualizados'}
    has_branding_folder = any(component & branding_context for component in components)
    return has_brand_folder and has_branding_folder


def _indexed_search(terms, limit, roots, query_words):
    if not INDEX_PATH.exists():
        return False, None
    try:
        placeholders = ','.join('?' for _ in terms)
        root_placeholders = ','.join('?' for _ in roots)
        with sqlite3.connect(INDEX_PATH, timeout=0.2) as db:
            db.execute('PRAGMA busy_timeout=200')
            indexed_roots = {row[0] for row in db.execute(f'SELECT root FROM root_index WHERE root IN ({root_placeholders})', roots)}
        rows = db.execute(f'''SELECT f.path,f.name,f.ext,SUM(t.in_name) AS score
                FROM terms t JOIN files f ON f.root=t.root AND f.path=t.path
                WHERE f.root IN ({root_placeholders}) AND t.token IN ({placeholders})
                GROUP BY f.root,f.path,f.name,f.ext
                HAVING COUNT(DISTINCT t.token)=?
                ORDER BY score DESC,f.name COLLATE NOCASE LIMIT ?''', (*roots, *sorted(terms), len(terms), max(limit * 40, 400))).fetchall()
        cards = []
        logo_intent = bool(query_words & LOGO_INTENT)
        brand_terms = terms - LOGO_INTENT
        ranked = []
        for path, name, ext, name_score in rows:
            if logo_intent and (_logo_conflict(name, path, brand_terms, query_words)
                                or not _is_logo_candidate(name, path, brand_terms)):
                continue
            path_folded = path.casefold().replace('\\', '/')
            rank = name_score
            if logo_intent:
                if 'marcas atualizadas' in path_folded or 'brands updated' in path_folded:
                    rank += 25
                if ext in {'ai','eps','svg','pdf'}:
                    rank += 12
                if any(word in path_folded for word in ('/antig','/obsolet','/desatualiz','/rascunho')):
                    rank -= 35
                if 'usar este' in Path(name).stem.casefold() or 'usar_este' in Path(name).stem.casefold():
                    rank += 50
            ranked.append((rank, path, name, ext))
        ranked.sort(key=lambda item: (-item[0], item[2].casefold(), item[1].casefold()))
        for _rank, path, name, ext in ranked[:limit]:
            card = {'path':path,'name':name,'type':ext,'size':''}
            cards.append(':::gravity-file:' + base64.b64encode(json.dumps(card, ensure_ascii=False).encode()).decode() + ':::')
        return set(roots) <= indexed_roots, '\n'.join(cards)
    except sqlite3.Error:
        return False, None


def search(query, root, limit=10, extra_roots=None):
    query_words = words(query)
    terms = query_words - STOP_WORDS
    if not terms:
        return None
    roots = list(dict.fromkeys(str(Path(p).expanduser()) for p in [root, *(extra_roots or [])] if p))
    start_indexing(roots)
    complete, indexed = _indexed_search(terms, limit, roots, query_words)
    if indexed:
        return indexed
    if complete:
        return None

    # First-run fallback stays short while the persistent index warms in background.
    ranked = []
    results = queue.Queue()
    deadline = time.monotonic() + 0.65

    def scan(configured_root, root_index):
        matches = []
        try:
            for directory, dirs, files in os.walk(configured_root, onerror=lambda _error: None):
                dirs[:] = [d for d in dirs if not d.startswith('.') and d.casefold() not in IGNORED]
                if time.monotonic() > deadline:
                    break
                for name in files:
                    name_terms = words(name)
                    path_terms = name_terms | words(directory)
                    if not terms <= path_terms:
                        continue
                    logo_intent = bool(query_words & LOGO_INTENT)
                    if logo_intent and (_logo_conflict(name, os.path.join(directory, name), terms - LOGO_INTENT, query_words)
                                        or not _is_logo_candidate(name, os.path.join(directory, name), terms - LOGO_INTENT)):
                        continue
                    path = os.path.join(directory, name)
                    card = {'path':path,'name':name,'type':Path(name).suffix.lstrip('.'),'size':''}
                    encoded = base64.b64encode(json.dumps(card, ensure_ascii=False).encode()).decode()
                    score = len(terms & name_terms) * 5
                    if logo_intent and ('marcas atualizadas' in path.casefold() or Path(name).suffix.lower() in {'.ai','.eps','.svg','.pdf'}):
                        score += 15
                    matches.append((score, root_index, name.casefold(), ':::gravity-file:' + encoded + ':::'))
        except (OSError, ValueError):
            pass
        results.put(matches)

    with INDEX_LOCK:
        # Do not suppress the first bounded search just because the background
        # indexer has already claimed the root; otherwise cold-start searches
        # return no local results until a full network walk finishes.
        fallback_roots = [path for path in roots if path not in INDEX_CHECKED]
    workers = [threading.Thread(target=scan, args=(path, index), daemon=True) for index, path in enumerate(fallback_roots)]
    for worker in workers:
        worker.start()
    for worker in workers:
        worker.join(max(0, deadline - time.monotonic()))
        if time.monotonic() >= deadline:
            break
    while not results.empty():
        ranked.extend(results.get_nowait())
    ranked.sort(key=lambda item: (-item[0], item[1], item[2]))
    return '\n'.join(item[3] for item in ranked[:limit]) or None
