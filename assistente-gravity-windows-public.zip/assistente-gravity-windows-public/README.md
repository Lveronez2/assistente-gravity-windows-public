# Assistente Gravity — Windows

Versão independente para Windows, derivada do Assistente Gravity para macOS. Mantém a identidade visual de vidro translúcido, reflexos e refração do Liquid Glass usando uma interface local no navegador Edge/Chrome. Não utiliza SwiftUI nem depende do repositório Mac durante a execução.

## Executar

1. Instale Python 3.11 ou mais recente.
2. Execute `start-windows.cmd`; a interface abre no Edge ou Chrome em http://127.0.0.1:8765.
3. Para respostas com IA e pesquisas na internet, instale e autentique o CLI Antigravity para Windows. O inicializador procura `agy` no PATH e no local padrão `%LOCALAPPDATA%\agy\bin\agy.exe`; `GRAVITY_CLI` pode apontar para outro executável.

Na primeira abertura, um guia explica como iniciar o Gravity, instalar o CLI e entrar com Google; depois, o tour apresenta as funções principais. O [guia completo de primeiro uso](docs/PRIMEIRO-USO.md) também pode ser aberto em Configurações.

Em ⚙️ Configurações, informe a pasta principal e uma pasta por linha em pastas adicionais. Caminhos UNC como `\\servidor\clientes` são aceitos; a conta Windows precisa ter permissão e estar conectada à rede/VPN. O status das pastas é exibido no mesmo painel. `GRAVITY_LOCAL` fornece a pasta principal inicial.

Na busca de arquivos, use o clipe ou arraste uma imagem/documento para orientar uma busca complexa. São aceitos arquivos de até 30 MB. O arquivo escolhido é enviado ao serviço local e disponibilizado ao CLI Antigravity apenas durante essa solicitação; ao enviar, a conta Antigravity conectada pode analisar a imagem ou ler o documento. A nova etapa do tour mostra esse fluxo. Anexos não são aceitos na conversa de pesquisa web.

O histórico, as preferências e os caminhos ficam em `%LOCALAPPDATA%\Assistente Gravity Web`. O painel Matriz separa o histórico de arquivos do Assistente Gravity do histórico de pesquisas rápidas na internet; conversas individuais podem ser excluídas. A aparência clara/escura e a intensidade de refração/reflexos são ajustáveis. Abrir usa o aplicativo padrão; revelar usa o Explorer; copiar usa o clipboard do Windows. O servidor escuta apenas em localhost e rejeita chamadas de outras origens.

## Estado e limites

O buscador mantém um índice SQLite em `%LOCALAPPDATA%` e o atualiza em segundo plano para entregar resultados repetidos rapidamente. Buscas diretas e erros simples de grafia usam o índice local sem iniciar a IA; somente consultas contextuais difíceis ou com referência anexada passam ao Antigravity. A pesquisa web pede fontes apenas quando o usuário solicita ou quando a pergunta depende de informação atual.

A interface é servida no navegador e não é um instalador `.exe`; mover a janela dentro da página funciona, mas arraste de arquivos depende das restrições do navegador. A seção de tokens herdada é experimental e não representa uma cota oficial. Pesquisa web depende do acesso web disponível no CLI.

O efeito de refração funciona em Chromium; outros navegadores usam blur como fallback. Movimento e transparência reduzidos são respeitados. O Windows ainda precisa de teste funcional em uma máquina Windows antes de distribuição.

## Validação

`PYTHONPATH=src python -m unittest discover -s tests -v` (no PowerShell, defina `$env:PYTHONPATH="src"` antes de executar `python -m unittest discover -s tests -v`)

O workflow executa verificações no Windows a cada push e pull request. Código Apple não faz parte desta versão; a origem desta adaptação é o commit `14fcb471c9b4ebef959ec78b48b24f01329d37bd` do repositório Mac.

O módulo `liquid-glass.js` é proveniente da skill local liquid-glass-web e mantém os créditos no cabeçalho. Antes de distribuição pública, confirmar a licença de redistribuição desse módulo.

O botão “Trocar conta Google” abre uma sessão interativa do CLI. Use `/logout` no prompt e siga a autenticação para entrar na outra conta; o estado compartilhado de login do Antigravity CLI segue a documentação oficial do produto.

## Organização e continuidade

Comece por `AGENTS.md`, `docs/ESTADO.md` e `docs/ARQUITETURA.md`. O estado atual fica nesses documentos; não mantenha transcrições ou cópias de sessões no repositório. Builds e dados privados são ignorados pelo Git.
