# Assistente Gravity para Windows

Cópia pública do código-fonte Windows, criada com histórico limpo. Não contém histórico de conversas nem configurações ou caminhos internos. O repositório de trabalho permanece privado.

## Requisitos

- Windows 10/11
- Python 3.11+
- Microsoft Edge ou Google Chrome

## Executar

Extraia o repositório e execute `start-windows.cmd`. A interface abre em `http://127.0.0.1:8765`. O app ainda não é um instalador `.exe`; esta edição precisa de validação funcional em PC Windows. O Antigravity CLI é opcional para recursos de IA e deve ser configurado separadamente. Escolha as pastas locais/rede que deseja pesquisar nas configurações.

## Privacidade e licenças

Dados, histórico, índice e credenciais são mantidos fora deste repositório e configurados por cada pessoa. `THIRD-PARTY-LICENSES.txt` contém a licença MIT do módulo `web/liquid-glass.js`.

O código do Assistente Gravity é público para consulta e download. Nenhuma licença de uso, modificação ou redistribuição foi incluída; peça autorização antes de reutilizar ou redistribuir.
