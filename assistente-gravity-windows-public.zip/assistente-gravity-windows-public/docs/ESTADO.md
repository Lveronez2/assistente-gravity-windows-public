# Estado atual

Atualizado em 2026-11-23.

- Adaptação independente em Python e navegador Chromium, ainda sem instalador nativo.
- Índice SQLite persistente para nomes e caminhos, aquecido em segundo plano por raiz local/UNC; buscas simples e grafias próximas retornam sem IA.
- Liquid Glass em JavaScript/CSS; histórico próprio.
- Pesquisas rápidas via CLI com resposta direta e esforço baixo; pesquisa/fontes externas sob demanda; histórico separado do histórico de arquivos.
- Configurações persistentes de conta, caminhos, claro/escuro e força do vidro/refração; primeiro acesso orienta como iniciar o Gravity, instalar/autenticar o CLI e depois apresenta o tour interativo.
- O terminal interativo do CLI auxilia a troca da conta Google; disponibilidade de acesso web, autenticação e compartilhamentos depende do PC Windows.
- A busca aceita uma imagem ou documento de até 30 MB por seleção ou arraste. O arquivo passa pelo serviço localhost, fica em uma pasta temporária somente durante a solicitação e é anexado ao escopo do CLI Antigravity; o tour interativo apresenta a função. Anexos não são aceitos na conversa de pesquisa web.
- Busca de logos valida marcas no nome/caminho, reduz resultados com outras marcas ou variantes de produto não solicitadas e prioriza pastas atualizadas e formatos vetoriais.
- O ranking de busca compara até 400 candidatos antes de escolher os resultados; telemetria ociosa foi reduzida para uma consulta a cada 15 segundos e pausada enquanto a janela fica oculta.
- O contorno prismático faz uma varredura luminosa suave em 20 segundos; brilho acompanha o controle de intensidade do vidro e respeita a preferência de movimento reduzido.
- Abrir e minimizar usa uma curva contínua de 420–520 ms, com squash-and-stretch perceptível, overshoot curto e assentamento suave entre o ícone e o painel. O brilho contínuo da borda pausa durante o movimento para evitar redesenhos concorrentes; movimento reduzido desativa a transição.
- Organização separa src, web, assets, docs e tests.
- Requer validação funcional em Windows e confirmação da licença do módulo de vidro antes de distribuição pública.

- Arraste exporta referências com codificação correta de caminhos de unidade e UNC, em modo cópia. Removido DownloadURL de file://; navegador não garante arraste nativo para Photoshop. Abrir/Explorer continuam sendo alternativas.
- Buscas simples são resolvidas no índice local. Consultas difíceis ou anexos usam o CLI com leitura limitada às pastas configuradas e ferramentas no sandbox; escrita, MCP e navegação ficam bloqueados.

- Busca contextual acelerada: correção de erros simples via vocabulário do índice, retorno imediato para buscas diretas, varredura focada na pasta do cliente quando identificada e mais tempo apenas para o fallback SMB de consultas com vários termos; IA somente para contexto difícil ou referência anexada. Removida a negação de comando que quebrava `run_command`.
- Busca de logo Poty tolera troca de letras em `poyt` mesmo antes do vocabulário SQLite terminar de aquecer; contexto de logo prioriza a marca e não dispara varredura de rede sem limite após uma correção sem resultados no índice.
- Busca de logos exige contexto explícito de logo/identidade, exclui mockups e arquivos gerados e atualiza arquivos irmãos diretamente nas pastas de logo identificadas pelo índice, evitando perder variações recentes no servidor.
- A busca de logos do servidor lê os arquivos irmãos da pasta exata encontrada pelo índice e filtra mockups/gerações; variações novas não ficam escondidas por um índice desatualizado.
- Busca contextual corrige erros de uma letra somente quando não existe caminho completo exato, exige candidato único recorrente, indexa a data de modificação em segundo plano e ordena resultados recentes primeiro em todas as raízes; busca de logo ignora palavras de intenção ao localizar a pasta do cliente e devolve até 100 correspondências.
- A busca de logo agora percorre de forma limitada a pasta do cliente no servidor, prioriza pastas institucionais e atualizadas e retorna as variantes encontradas mesmo que o índice SMB esteja incompleto; sem resultados, não inicia varredura ampla nem retorna mockups da busca contextual.
- Busca contextual: a correção de grafia compara a frequência da palavra digitada com candidatos de uma edição; um erro isolado não bloqueia a correção só porque aparece em algum caminho não relacionado. Os resultados de logos continuam reunindo variantes válidas e ordenando por data de modificação, mais recentes primeiro.
- Busca de logos consulta primeiro o índice aquecido e faz a varredura SMB limitada somente quando ele não consegue responder, reduzindo atrasos recorrentes em pesquisas simples.
