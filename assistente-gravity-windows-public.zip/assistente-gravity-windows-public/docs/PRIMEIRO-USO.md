# Primeiro uso — Assistente Gravity para Windows

## Iniciar o Gravity

Esta edição ainda não tem um instalador `.exe`: ela roda localmente no Edge ou Chrome. Instale Python 3.11 ou mais recente, abra a pasta do projeto e execute `start-windows.cmd`. O inicializador abre a interface em `http://127.0.0.1:8765`. Para iniciar de novo, execute o mesmo arquivo. Veja o [README do Windows](../README.md) ou [baixe o Python](https://www.python.org/downloads/windows/).

## Instalar o Antigravity CLI

Abra o PowerShell e execute o instalador oficial do Google:

```powershell
irm https://antigravity.google/cli/install.ps1 | iex
```

O executável padrão é `%LOCALAPPDATA%\agy\bin\agy.exe`. A instalação também pode ser conferida na [documentação oficial do CLI](https://antigravity.google/docs/getting-started?tab=cli).

## Entrar com Google

No PowerShell, execute `agy`. Na primeira execução, o CLI abre o navegador para autenticação. Escolha Google OAuth para uma conta pessoal e conclua o login no navegador; depois, retorne ao terminal. As credenciais são armazenadas pelo CLI no Gerenciador de Credenciais do Windows. O Gravity não solicita nem armazena senha, códigos OAuth ou tokens. Consulte o [guia oficial de autenticação](https://antigravity.google/docs/install/).

Se o CLI já estiver instalado, use **Configurações → Trocar conta Google**. No terminal, digite `/logout` e siga o novo fluxo de login. O botão **Verificar instalação** confirma apenas que o executável existe; não verifica se a conta está autenticada.

## Começar a usar

Volte ao Gravity e conclua o tour interativo. Configure a pasta principal e, se necessário, acrescente pastas adicionais ou caminhos UNC do servidor em **Configurações**. A busca local funciona mesmo sem login; as respostas da IA precisam do Antigravity CLI autenticado.

O guia de primeiro acesso pode ser reaberto em **Configurações → Guia de primeiro acesso**. As etapas e links não iniciam instalação nem login por conta própria.
