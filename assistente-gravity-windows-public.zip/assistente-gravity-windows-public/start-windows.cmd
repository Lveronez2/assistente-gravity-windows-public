@echo off
cd /d "%~dp0"
where py >nul 2>nul
if errorlevel 1 (
 echo Instale Python 3 para executar o Gravity.
 pause
 exit /b 1
)
start "Gravity" http://127.0.0.1:8765
py -3 src\server.py
pause
