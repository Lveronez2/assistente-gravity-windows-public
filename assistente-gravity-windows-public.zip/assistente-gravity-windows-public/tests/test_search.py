import base64
import json
import tempfile
import unittest
from pathlib import Path
from local_search import search

class LocalSearchTests(unittest.TestCase):
    def test_unicode_and_actual_paths(self):
        with tempfile.TemporaryDirectory() as root:
            target = Path(root, 'Árvore final.pdf')
            target.write_text('fixture')
            result = search('quero arvore pdf', root)
            self.assertIsNotNone(result)
            fields = json.loads(base64.b64decode(result.removeprefix(':::gravity-file:').removesuffix(':::')))
            self.assertEqual(fields['path'], str(target.resolve()))
    def test_missing_does_not_invent_results(self):
        with tempfile.TemporaryDirectory() as root:
            self.assertIsNone(search('inexistente', root))
    def test_limit(self):
        with tempfile.TemporaryDirectory() as root:
            for i in range(15): Path(root, f'logo{i}.ai').touch()
            self.assertEqual(len(search('ai',root).splitlines()),10)

if __name__ == '__main__': unittest.main()
